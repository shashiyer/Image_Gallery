$(document).ready(function(){
  $('[data-toggle="popover"]').popover();   


  $(".card-img-top").click(function(){
    $(".card-img-top").fadeTo("slow", 0.7);
  });

});