$(document).ready(function(){
  $('[data-toggle="popover"]').popover();   


  $(".card-img-top").click(function(){
    $(".card-img-top").fadeTo("slow", 0.7);
  });

});

$(document).ready(function() {
    $('#myCarousel').carousel({
	    interval: 10000
	})
});