function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
    document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
  }
  
  function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
    document.body.style.backgroundColor = "white";
  }

  //   $(document).ready(function(){
  // $(".open").click(function(){
  //   $(".card-img-top").fadeTo("slow", 0.15);
  // });
  //   });

  function zoomin(){
        var myImg = document.getElementById("sky");
        var currWidth = myImg.clientWidth;
        if(currWidth == 500){
            alert("Maximum zoom-in level reached.");
        } else{
            myImg.style.width = (currWidth + 50) + "px";
        } 
    }
    function zoomout(){
        var myImg = document.getElementById("sky");
        var currWidth = myImg.clientWidth;
        if(currWidth == 50){
            alert("Maximum zoom-out level reached.");
        } else{
            myImg.style.width = (currWidth - 50) + "px";
        }
    }

    function bikes()
    {
      var img1 = document.getElementById("img1");
      var img2b = document.getElementById("img2b");
      var r1 = document.getElementById("r1");
      var multistrada = document.getElementById("multistrada");
      var panigale = document.getElementById("panigale");
      var diavel = document.getElementById("diavel");

      if(img1 == "img1")
      {
        window.location.assign("C:/Users/Trainee-15/Image_Gallery/content/images/img1.gif");
      }

      else if(img2b == "img2b")
      {
        window.location.assign("C:/Users/Trainee-15/Image_Gallery/content/images/img2b.jpg");
      }
      
      else if(r1 == "r1")
      {
        window.location.assign("C:/Users/Trainee-15/Image_Gallery/content/images/r1.jpg");
      }

      else if(multistrada == "multistrada")
      {
        window.location.assign("C:/Users/Trainee-15/Image_Gallery/content/images/multistrada.jpg");
      }

      else if(panigale == "panigale")
      {
        window.location.assign("C:/Users/Trainee-15/Image_Gallery/content/images/panigale.jpg");
      }

      else if(diavel == "diavel")
    {
        window.location.assign("C:/Users/Trainee-15/Image_Gallery/content/images/diavel.jpg");
    }

    }
  