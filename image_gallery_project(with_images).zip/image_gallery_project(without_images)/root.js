$(function()
{
    $(img).hide(2000);
});